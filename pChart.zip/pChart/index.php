
<head>
<meta http-equiv="Content-Language" content="es-mx">
<title>Usuarios registrados</title>
<script type="text/javascript" src="javascript.js"></script>

<STYLE>
<!--
.menu A:link    {color:BLACK; text-decoration:none;}
.menu A:visited {color:BLACK; text-decoration:none;}
.menu A:active  {color:BLACK; text-decoration:none;}
.menu A:hover   {	padding-bottom: 1px;
					border-bottom: 2px solid #0000ff;
					background: transparent;
					color: #0000ff;
					text-decoration: none; }

.normal A:link		{color:BLACK; text-decoration:none;}
.normal A:visited	{color:BLACK; text-decoration:none;}
.normal A:active	{color:BLACK; text-decoration:none;}
.normal A:hover		{color:BLACK; text-decoration:underline;}

A:link		{color:BLACK; text-decoration:none;}
A:visited	{color:BLACK; text-decoration:none;}
A:active	{color:BLACK; text-decoration:none;}
A:hover	{color:BLUE; text-decoration:underline;}

td {
	font-family: Verdana, Geneva, sans-serif;
	font-size:12px;
}
-->
</STYLE>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script type="text/JavaScript">
<!--
function timedRefresh(timeoutPeriod) {
	setTimeout("location.reload(true);",timeoutPeriod);
}
//   -->
</script>

</head>

<body onLoad="JavaScript:timedRefresh(300000);">

<p align="center"><img src="http://www.conricyt.mx/conremoto/auth/images/header-summon-background-01.png" width="858" height="200" alt="Conricyt">
		

<?PHP
date_default_timezone_set('Mexico_City');

$link = mysql_connect('localhost','conricyt_4r3m070','3zpr0x1blu3')
    or die('Imposible conectar al servidor: ' . mysql_error());

mysql_select_db('conricyt_proxy') or die('Imposible seleccionar la base de datos.' . mysql_error());

$query = "SELECT COUNT(DISTINCT institution) FROM users";
$result = mysql_query($query) or die('Fallo al contar registros: ' . mysql_error());
$institutions = mysql_fetch_row($result);						

$fecha=date('j \- F \- Y');
print"<br><div align='center'><font face='Verdana' size='3'>USUARIOS REGISTRADOS AL $fecha</font></div><br>
<div align='center'>
<table border='1' cellpadding='3'>
  <tr>
    <td><b>INSTITUCI�N</b></td>
    <td align='center'><b>Total de <br />registros</b></td>
    <td>T�cnico</td>
    <td>Estudiante de<br />
Especialidad</td>
    <td>Estudiante de<br />
    Licenciatura</td>
    <td>Estudiante de<br />
    Maestr�a</td>
    <td>Estudiante de<br />
      Doctorado</td>
    <td>Acad�mico</td>
    <td>Bibliotecario</td>
    <td>Investigador</td>
    <td>Referencista</td>
    <td>Otro</td>
  </tr>";

$total=0;
$consulta = "SELECT id, inst_name FROM inst ORDER BY inst_name";
$resulta = mysql_query($consulta) or die('Error: ' . mysql_error());
while ($inst = mysql_fetch_row($resulta)) {

$query = "SELECT count(*) FROM users WHERE institution = '$inst[0]'";
$result = mysql_query($query) or die('Fallo al contar instituciones: ' . mysql_error());
$row = mysql_fetch_row($result);						

if ($row[0] != 0) {print"
  <tr>
	<td><font face='Verdana' size='2'>$inst[1]</font></td>
	<td align='center'><font face='Verdana' size='2'>$row[0]</font></td>";

$query = "SELECT count(*) FROM users WHERE institution = '$inst[0]' AND level = 1";
$result = mysql_query($query) or die('Fallo al contar rol: ' . mysql_error());	
$level = mysql_fetch_row($result);
$level1 = $level1+$level[0];
if ($level[0] == 0) $level[0] = "";
print"<td align='center'><font face='Verdana' size='2'>$level[0]</font></td>";

$query = "SELECT count(*) FROM users WHERE institution = '$inst[0]' AND level = 2";
$result = mysql_query($query) or die('Fallo al contar rol: ' . mysql_error());	
$level = mysql_fetch_row($result);
$level2 = $level2+$level[0];
if ($level[0] == 0) $level[0] = "";
print"<td align='center'><font face='Verdana' size='2'>$level[0]</font></td>";

$query = "SELECT count(*) FROM users WHERE institution = '$inst[0]' AND level = 3";
$result = mysql_query($query) or die('Fallo al contar rol: ' . mysql_error());	
$level = mysql_fetch_row($result);
$level3 = $level3+$level[0];
if ($level[0] == 0) $level[0] = "";
print"<td align='center'><font face='Verdana' size='2'>$level[0]</font></td>";

$query = "SELECT count(*) FROM users WHERE institution = '$inst[0]' AND level = 4";
$result = mysql_query($query) or die('Fallo al contar rol: ' . mysql_error());	
$level = mysql_fetch_row($result);
$level4 = $level4+$level[0];
if ($level[0] == 0) $level[0] = "";
print"<td align='center'><font face='Verdana' size='2'>$level[0]</font></td>";

$query = "SELECT count(*) FROM users WHERE institution = '$inst[0]' AND level = 9";
$result = mysql_query($query) or die('Fallo al contar rol: ' . mysql_error());	
$level = mysql_fetch_row($result);
$level9 = $level9+$level[0];
if ($level[0] == 0) $level[0] = "";
print"<td align='center'><font face='Verdana' size='2'>$level[0]</font></td>";

$query = "SELECT count(*) FROM users WHERE institution = '$inst[0]' AND level = 5";
$result = mysql_query($query) or die('Fallo al contar rol: ' . mysql_error());	
$level = mysql_fetch_row($result);
$level5 = $level5+$level[0];
if ($level[0] == 0) $level[0] = "";
print"<td align='center'><font face='Verdana' size='2'>$level[0]</font></td>";

$query = "SELECT count(*) FROM users WHERE institution = '$inst[0]' AND level = 6";
$result = mysql_query($query) or die('Fallo al contar rol: ' . mysql_error());	
$level = mysql_fetch_row($result);
$level6 = $level6+$level[0];
if ($level[0] == 0) $level[0] = "";
print"<td align='center'><font face='Verdana' size='2'>$level[0]</font></td>";

$query = "SELECT count(*) FROM users WHERE institution = '$inst[0]' AND level = 7";
$result = mysql_query($query) or die('Fallo al contar rol: ' . mysql_error());	
$level = mysql_fetch_row($result);
$level7 = $level7+$level[0];
if ($level[0] == 0) $level[0] = "";
print"<td align='center'><font face='Verdana' size='2'>$level[0]</font></td>";

$query = "SELECT count(*) FROM users WHERE institution = '$inst[0]' AND level = 8";
$result = mysql_query($query) or die('Fallo al contar rol: ' . mysql_error());	
$level = mysql_fetch_row($result);
$level8 = $level8+$level[0];
if ($level[0] == 0) $level[0] = "";
print"<td align='center'><font face='Verdana' size='2'>$level[0]</font></td>";

$query = "SELECT count(*) FROM users WHERE institution = '$inst[0]' AND level = 10";
$result = mysql_query($query) or die('Fallo al contar rol: ' . mysql_error());	
$level = mysql_fetch_row($result);
$level10 = $level10+$level[0];
if ($level[0] == 0) $level[0] = "";
print"<td align='center'><font face='Verdana' size='2'>$level[0]</font></td>";

	
print"	
  </tr>";
	}
$total = $total+$row[0];	
}

print"
  <tr>
    <td align='right'><b>TOTALES:</b></td>
	<td align='center'><b>$total</b></td>
    <td align='center'><b>$level1</b></td>
	<td align='center'><b>$level2</b></td>
	<td align='center'><b>$level3</b></td>
	<td align='center'><b>$level4</b></td>
	<td align='center'><b>$level9</b></td>
	<td align='center'><b>$level5</b></td>
	<td align='center'><b>$level6</b></td>
	<td align='center'><b>$level7</b></td>
	<td align='center'><b>$level8</b></td>
	<td align='center'><b>$level10</b></td>
  </tr>
  <tr>
    <td>INSTITUCI�N</td>
    <td>No. de <br />registros</td>
    <td>T�cnico</td>
    <td>Estudiante de<br />
Especialidad</td>
    <td>Estudiante de<br />
    Licenciatura</td>
    <td>Estudiante de<br />
    Maestr�a</td>
    <td>Estudiante de<br />
      Doctorado</td>
    <td>Acad�mico</td>
    <td>Bibliotecario</td>
    <td>Investigador</td>
    <td>Referencista</td>
    <td>Otro</td>
  </tr>";

print"
</table></div>
<br><div align='center'><font face='Verdana' size='2'>$total registros procesados de $institutions[0] instituciones distintas.</font></div><br>";

include("pChart/pData.class");
include("pChart/pChart.class");

 // Dataset definition 
 $DataSet = new pData;
 $DataSet->AddPoint(array($level1,$level2,$level3,$level4,$level9,$level5,$level6,$level7,$level8,$level10),"Serie1");
 $DataSet->AddPoint(array("T�cnico: $level1","Estudiante de Especialidad: $level2","Estudiante de Licenciatura: $level3","Estudiante de Maestr�a: $level4","Estudiante de Doctorado: $level9","Acad�mico: $level5","Bibliotecario: $level6","Investigador: $level7","Referencista: $level8","Otro: $level10"),"Serie2");
 $DataSet->AddAllSeries();
 $DataSet->SetAbsciseLabelSerie("Serie2");

 // Initialise the graph
 $Test = new pChart(768,280);
 $Test->drawFilledRoundedRectangle(7,7,478,258,5,240,240,240);
 $Test->drawRoundedRectangle(5,5,480,260,5,230,230,230);
 $Test->createColorGradientPalette(195,204,56,223,110,41,5);
 $Test->setColorPalette(0,0,163,221); 
 $Test->setColorPalette(1,255,0,120);
 $Test->setColorPalette(2,160,48,51); 
 $Test->setColorPalette(3,255,255,0);
 $Test->setColorPalette(4,0,183,96);
 $Test->setColorPalette(5,91,2,122);
 $Test->setColorPalette(6,128,255,0);
 $Test->setColorPalette(7,255,128,0);
 $Test->setColorPalette(8,0,255,128);
 $Test->setColorPalette(9,0,128,255);
  

 // Draw the pie chart
 $Test->setFontProperties("Fonts/tahoma.ttf",10);
 $Test->AntialiasQuality = 0;
 $Test->drawPieGraph($DataSet->GetData(),$DataSet->GetDataDescription(),220,120,150,PIE_PERCENTAGE,TRUE,50,20,5);
 $Test->drawPieLegend(440,15,$DataSet->GetData(),$DataSet->GetDataDescription(),250,250,250);

 // Write the title
 $Test->setFontProperties("Fonts/MankSans.ttf",10);
 $Test->drawTitle(10,20,"Usuarios registrados",0,0,0);

 $Test->Render("usuarios.png");
 echo("<div align='center'><img src='usuarios.png?");
 echo rand(1,65536);
 echo("'></div><br><br><br><br>");

?>
