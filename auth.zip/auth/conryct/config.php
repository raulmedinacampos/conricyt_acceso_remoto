<?php
define('DB_HOST', ' 66.147.244.209');
define('DB_USER', 'etecheng_amrueda');
define('DB_PASSWORD', 'valen2006');
define('DB_NAME', 'etecheng_Conricyt_Institutions');

?>